﻿using System;
using System.Collections.Generic;

class Transaction
{
    public string Type { get; set; }
    public double Amount { get; set; }
    public DateTime Timestamp { get; set; }

    public Transaction(string type, double amount)
    {
        Type = type;
        Amount = amount;
        Timestamp = DateTime.Now;
    }

    public override string ToString()
    {
        return $"{Timestamp}: {Type} of {Amount}";
    }
}

class User
{
    public string Name { get; set; }
    public int AccountNumber { get; set; }
    public int PIN { get; set; }
}

class ATM
{
    private double balance;
    private User user;
    private List<Transaction> transactions;

    public ATM(double initialBalance, User currentUser)
    {
        balance = initialBalance;
        user = currentUser;
        transactions = new List<Transaction>();
    }

    public double GetBalance()
    {
        return balance;
    }

    public void Withdraw(double amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            transactions.Add(new Transaction("Withdrawal", amount));
            Console.WriteLine($"Successfully withdrew {amount}. New balance: {balance}");
        }
        else
        {
            Console.WriteLine("Invalid amount or insufficient balance.");
        }
    }

    public void Deposit(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
            transactions.Add(new Transaction("Deposit", amount));
            Console.WriteLine($"Successfully deposited {amount}. New balance: {balance}");
        }
        else
        {
            Console.WriteLine("Invalid amount.");
        }
    }

    public bool ValidatePIN(int enteredPIN)
    {
        return enteredPIN == user.PIN;
    }

    public void ShowTransactionHistory()
    {
        Console.WriteLine("Transaction History:");
        foreach (Transaction transaction in transactions)
        {
            Console.WriteLine(transaction);
        }
    }
}

class Program
{
    static void Main()
    {
        User user = new User { Name = "Paulos Kekana", AccountNumber = 123456, PIN = 1234 };
        ATM atm = new ATM(1000, user);

        Console.WriteLine("Welcome to the ATM.");

        while (true)
        {
            Console.WriteLine("Enter your PIN:");
            int enteredPIN = int.Parse(Console.ReadLine());

            if (atm.ValidatePIN(enteredPIN))
            {
                Console.WriteLine("PIN validated.");
                break;
            }
            else
            {
                Console.WriteLine("Invalid PIN. Please try again.");
            }
        }

        while (true)
        {
            Console.WriteLine("Select an option:");
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Withdraw");
            Console.WriteLine("3. Deposit");
            Console.WriteLine("4. Transaction History");
            Console.WriteLine("5. Exit");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Your balance is {atm.GetBalance()}");
                    break;
                case 2:
                    Console.Write("Enter amount to withdraw: ");
                    double withdrawAmount = double.Parse(Console.ReadLine());
                    atm.Withdraw(withdrawAmount);
                    break;
                case 3:
                    Console.Write("Enter amount to deposit: ");
                    double depositAmount = double.Parse(Console.ReadLine());
                    atm.Deposit(depositAmount);
                    break;
                case 4:
                    atm.ShowTransactionHistory();
                    break;
                case 5:
                    Console.WriteLine("Thank you for using the ATM.");
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}
